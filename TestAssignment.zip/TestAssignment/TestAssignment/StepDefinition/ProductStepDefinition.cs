﻿
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using TechTalk.SpecFlow;
using TestAssignment.Helper;

namespace TestAssignment.StepDefinition
{
    [Binding]
    public sealed class ProductStepDefinition
    {
        [Given(@"I have a list of products to view")]
        public void GivenIHaveAListOfProductsToView()
        {
            ScenarioContext.Current.Pending();
        }

        [Given(@"I have a (.*), (.*), (.*), (.*) and (.*)")]
        public void GivenIHaveAAnd(string productName, string type, string upc, string description, string model)
        {
            ScenarioContextWrapper.SetContextObject("productName", productName);
            ScenarioContextWrapper.SetContextObject("type", type);
            ScenarioContextWrapper.SetContextObject("upc", upc);
            ScenarioContextWrapper.SetContextObject("description", description);
            ScenarioContextWrapper.SetContextObject("model", model);
        }

        [Given(@"I have a product id (.*)")]
        public void GivenIHaveAProductId(string productId)
        {
            ScenarioContextWrapper.SetContextObject("productId", productId);
        }

        [Given(@"I have a product details (.*) and (.*)")]
        public void GivenIHaveAProductDetailsAndTestproductname(string productId ,string productName)
        {
            ScenarioContextWrapper.SetContextObject("productId", productId);
            ScenarioContextWrapper.SetContextObject("productName", productName);
        }

        [Given(@"I have a invalid product id (.*)")]
        public void GivenIHaveAInvalidProductId(int invalidProductId)
        {
            ScenarioContextWrapper.SetContextObject("productId", invalidProductId);
        }

        [When(@"I make a request to get list of products")]
        public void WhenIMakeARequestToGetListOfProducts()
        {
            var restRequest = BuildApiRequest.BuildGetListOfProducts();
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, "localhost:3030/");
            ScenarioContextWrapper.SetContextObject("ProductResponse", restResponse);
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("StatusCode", (int)statusCode);
        }

        [When(@"I make a request to create a product")]
        public void WhenIMakeARequestToCreateAProduct()
        {
            var productName = ScenarioContextWrapper.GetContextObject<string>("productName");
            var productType = ScenarioContextWrapper.GetContextObject<string>("type");
            var upc = ScenarioContextWrapper.GetContextObject<string>("upc");
            var description = ScenarioContextWrapper.GetContextObject<string>("description");
            var model = ScenarioContextWrapper.GetContextObject<string>("productName");
            var restRequest = BuildApiRequest.BuildCreateProduct(productName, productType, upc, description, model);
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, "localhost:3030/");
            ScenarioContextWrapper.SetContextObject("ProductResponse", restResponse);
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("StatusCode", (int)statusCode);
        }

        [When(@"I make a request to delete a product")]
        public void WhenIMakeARequestToDeleteAProduct()
        {
            var productId = ScenarioContextWrapper.GetContextObject<string>("productId");
            var restRequest = BuildApiRequest.BuildDeleteProduct(productId);
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, "localhost:3030/");
            ScenarioContextWrapper.SetContextObject("ProductResponse", restResponse);
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("StatusCode", (int)statusCode);
        }

        [When(@"I make a request to get a product details")]
        public void WhenIMakeARequestToGetAProductDetails()
        {
            var productId = ScenarioContextWrapper.GetContextObject<string>("productId");
            var restRequest = BuildApiRequest.BuildGetProduct(productId);
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, "localhost:3030/");
            ScenarioContextWrapper.SetContextObject("ProductResponse", restResponse);
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("StatusCode", (int)statusCode);
        }

        [When(@"I make a request to update a product details")]
        public void WhenIMakeARequestToUpdateAProductDetails()
        {
            var productId = ScenarioContextWrapper.GetContextObject<string>("productId");
            var productName = ScenarioContextWrapper.GetContextObject<string>("productName");
            var restRequest = BuildApiRequest.BuildUpdateProduct(productId, productName);
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, "localhost:3030/");
            ScenarioContextWrapper.SetContextObject("ProductResponse", restResponse);
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("StatusCode", (int)statusCode);
        }

        [Then(@"The list of product details should be retrieved with (.*) response code")]
        public void ThenTheListOfProductDetailsShouldBeRetrievedWithResponseCode(int responseCode)
        {
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("StatusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }

        [Then(@"The product should be created with (.*) response code")]
        public void ThenTheProductShouldBeCreatedWithResponseCode(int responseCode)
        {
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("StatusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }

        [Then(@"The product should be deleted with (.*) response code")]
        public void ThenTheProductShouldBeDeletedWithResponseCode(int responseCode)
        {
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("StatusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }

        [Then(@"The product details should be displayed with (.*) response code")]
        public void ThenTheProductDetailsShouldBeDisplayedWithResponseCode(int responseCode)
        {
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("StatusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }

        [Then(@"The product details should be updated with (.*) response code")]
        public void ThenTheProductDetailsShouldBeUpdatedWithResponseCode(int responseCode)
        {
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("StatusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }

        [Then(@"The error message should be displayed with (.*) response code")]
        public void ThenTheErrorMessageShouldBeDisplayedWithResponseCode(int responseCode)
        {
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("StatusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }
    }
}
