﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TestAssignment.Helper
{
    public class ScenarioContextWrapper
    {
        public static void SetContextObject<T>(string name, T value)
        {
            if (ScenarioContext.Current.ContainsKey(name))
            {
                ScenarioContext.Current.Remove(name);
            }

            ScenarioContext.Current.Add(name, value);
        }

        public static T GetContextObject<T>(string name)
        {
            if (ScenarioContext.Current.ContainsKey(name))
            {
                return (T)ScenarioContext.Current[name];
            }

            return default(T);
        }
    }
}
