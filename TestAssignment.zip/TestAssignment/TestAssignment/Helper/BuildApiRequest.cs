﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAssignment.Helper
{
    public class BuildApiRequest
    {
        public static RestRequest BuildGetListOfProducts()
        {
            var restRequest = new RestRequest
            {
                Method = Method.GET,
                Resource = $"products",
                RequestFormat = DataFormat.Json
            };
            return restRequest;
        }

        public static RestRequest BuildCreateProduct(string productName, string type, string upc, string description, string model)
        {
            var restRequest = new RestRequest
            {
                Method = Method.POST,
                Resource = $"products",
                RequestFormat = DataFormat.Json
            };
            restRequest.AddBody(new ProductRequest
            {
                ProductName=productName,
                Type=type,
                Upc=upc,
                Description=description,
                Model=model
            });
            return restRequest;
        }

        public static RestRequest BuildDeleteProduct(string productId)
        {
            var restRequest = new RestRequest
            {
                Method = Method.DELETE,
                Resource = string.Format("products/{0}", productId),
                RequestFormat = DataFormat.Json
            };
            return restRequest;
        }

        public static RestRequest BuildGetProduct(string productId)
        {
            var restRequest = new RestRequest
            {
                Method = Method.GET,
                Resource = string.Format("products/{0}", productId),
                RequestFormat = DataFormat.Json
            };
            return restRequest;
        }

        public static RestRequest BuildUpdateProduct(string productId, string productName)
        {
            var restRequest = new RestRequest
            {
                Method = Method.PATCH,
                Resource = string.Format("products/{0}", productId),
                RequestFormat = DataFormat.Json
            };
            return restRequest;
        }
    }
}
        
    



